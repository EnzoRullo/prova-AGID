import sys
import requests
import csv
import os
import json
from requests.auth import HTTPBasicAuth
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

def analytics_api(method,idSites,period,date):
    url="https://api-coll.webanalytics.italia.it/data/analytics"
    id_list=[]
    if period == None:
        period = "day"
    if date == None:
        date = "2025-02-15"

    absolute_file_path = Path(os.path.abspath(__file__))
    out_path_csv=file_exist(str(absolute_file_path.parent.parent)+'/output/output.csv')
    out_path_json=file_exist(str(absolute_file_path.parent.parent)+'/output/output.json')

    if len(idSites)==0:
        
        in_path=str(absolute_file_path.parent.parent)+'/websites.csv'
        with open(in_path,mode='r',newline='',encoding='utf-8') as input_file:
            reader= csv.DictReader(input_file,delimiter=";")
            column_name='analytics_id'
            id_list=[row[column_name] for row in reader]
    else:
        id_list=[*idSites]
    
    params={
            "module":"API",
            "method":method,
            "period":period,
            "date":date 
        }
    with ThreadPoolExecutor(max_workers=1) as ex:
        futures = [ex.submit(the_request,params,s,url,index,out_path_json,out_path_csv) for index, s in enumerate(id_list)]
        #res = []
        for future in tqdm(as_completed(futures), total=len(futures), desc="Progress"):
            future.result()
            #res.append(future.result())
            #print(f"Progress--->{len(res)/(len(id_list)/100)} %")

        
   

def the_request(params,idSite,url,index,out_path_json,out_path_csv):
    params["idSite"]=idSite
    username="6f0b6931-2a84-424b-9a8b-12771bfb0d7a"
    password="8075ba72-ff79-4062-b871-815eba3f66a3"

    res=requests.get(url, params=params, auth=HTTPBasicAuth(username, password))

    if res.status_code == 200:
        data= res.json()
        #in_csv(idSite,[data],index,date,out_path_csv)
        in_json(idSite,data,index,date,out_path_json)
    else:
        print(f"Errore {res.status_code}")

    return idSite
        


def in_csv(idSite,data,index,date,out_path):
    if data:
        #mode="w"
        #if index != 0:
        #    mode="a"
        
        with open(out_path, mode='a', newline="", encoding="utf-8") as file:
            field_names = ['idSite','data',*data[0].keys()]
            writer=csv.DictWriter(file,fieldnames=field_names)
            if file.tell() == 0:
                writer.writeheader()
            data[0]['idSite']=idSite
            data[0]['data']=date
            writer.writerows(data)
    else:
        print("nessun dato da stampare su CSV")


def in_json(idSite,data,index,date,out_path):
    content=[]
    if data:
        data['idSite']=idSite
        data['data']=date
        if not os.path.exists(out_path):
            with open(out_path, mode='w') as file:
                json.dump([data], file, indent=4)
        else:
            with open(out_path,mode='r') as file:
                try:
                    content= json.load(file)
                except json.JSONDecodeError:
                    content= []
        content.append(data)
        with open(out_path, mode='w') as file:
            json.dump(content, file, indent=4)
    else:
        print("nessun dato da stampare sul JSON")


def file_exist(path):
    n=0
    exist=True
    base_path, ext= os.path.splitext(path)
    out_path=base_path+ext
    while exist:
        if n!=0:
            out_path=base_path+'_'+str(n)+ext
        if os.path.exists(out_path):
            n+=1
        else:
            exist=False
    return out_path    

            


if __name__ == "__main__":
    method=sys.argv[1]
    idSites='[]'
    period=None
    date = None

    if len(sys.argv) > 2:
        idSites=sys.argv[2]
    if len(sys.argv) > 3:
        period=sys.argv[3]
    if len(sys.argv) > 4:
        date=sys.argv[4]
    analytics_api(method,json.loads(idSites),period, date)


    
